#!/usr/bin/env python3
# logics/mysunpos.py

#    crontab = init = Init
#    cycle = 300

#logfsun = logging.getLogger('q21-sun')
#logfmoon = logging.getLogger('q21-moon')


logic_name = "mysunpos"
# logger.warning("logic "+logic_name+": trigger[source] = " + str(trigger['source']) + ", trigger[by] = " + str(trigger['by']) + ", trigger[value] = " + str(trigger['value']) )

if sh.sun:

#
# azimuth, altitude = sh.sun.pos() # return the current sun position
# azimuth, altitude = sh.sun.pos(30) # return the sun position 30 minutes in the future.
#

	# sun
	
    azimuth, elevation = sh.sun.pos()
    wrk = str(azimuth).split(':')
    sh.mysun.azimuth( round( int(wrk[0]) + int(wrk[1])/60, 1 ), logic.lname )
    wrk = str(elevation).split(':')
    if wrk[0][0] == '-':
        sh.mysun.elevation( round( int(wrk[0]) - int(wrk[1])/60, 1 ), logic.lname )
    else:
        sh.mysun.elevation( round( int(wrk[0]) + int(wrk[1])/60, 1 ), logic.lname )
#    logger.warning( "logic "+logic_name+": azimuth="+str(azimuth)+", az-dez="+str(sh.mysun.azimuth())+", elevation="+str(elevation)+", el-dez="+str(sh.mysun.elevation()) )

#    logfsun.info("logic: Azimuth = " + str(sh.mysun.azimuth()) + ", Elevation = " + str(sh.mysun.elevation()) )


	# moon
	
    azimuth, elevation = sh.moon.pos()
    wrk = str(azimuth).split(':')
    sh.mymoon.azimuth( round( int(wrk[0]) + int(wrk[1])/60, 1 ), logic.lname )
    wrk = str(elevation).split(':')
    if wrk[0][0] == '-':
        sh.mymoon.elevation( round( int(wrk[0]) - int(wrk[1])/60, 1 ), logic.lname )
    else:
        sh.mymoon.elevation( round( int(wrk[0]) + int(wrk[1])/60, 1 ), logic.lname )

#    logfmoon.info("logic: Azimuth = " + str(sh.mymoon.azimuth()) + ", Elevation = " + str(sh.mymoon.elevation()) )
