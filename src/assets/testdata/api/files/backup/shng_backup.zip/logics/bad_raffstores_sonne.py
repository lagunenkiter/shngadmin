#!/usr/bin/env python3
# logics/bad_raffstores_sonne.py
#
# Bad Beschattung

#    watch_item = mysun.azimuth | mysun.elevation

logfsun = logging.getLogger('q21-sun')
logf = logging.getLogger('q21')
logsys = logging.getLogger('syslog')

logic_name = "bad_rs_sonne"

#logger.warning("logic "+logic_name+": trigger[source] = " + str(trigger['source']) + ", trigger[by] = " + str(trigger['by']) + ", trigger[value] = " + str(trigger['value']) )



## BAD Raffstores hochfahren
#
#  @param sh       Object pointer to smarthome master object
#
def raffstores_up(sh, azimuth):
    global logf
    global logsys
    raffstorepos = 0
    if sh.wohnung.bad.raffstore.raffstore_pos() != raffstorepos:
        sh.wohnung.bad.raffstore.raffstore_pos(raffstorepos)
        sh.wohnung.bad.raffstore.lamellen_pos(0)
        logf.info("BAD raffstores_up(): Azimuth="+str(azimuth)+"°, Raffstorepos="+str(raffstorepos)+"%")
        logsys.debug("Beschattung BAD Raffstore "+str(raffstorepos)+"%")
    return


## BAD Raffstores runterfahren
#
#  @param sh       Object pointer to smarthome master object
#
def raffstores_down(sh, azimuth):
    global logf
    global logsys
    raffstorepos = sh.raffstores.maxpos()
    if round(sh.wohnung.bad.raffstore.raffstore_pos()) != raffstorepos:
        sh.wohnung.bad.raffstore.raffstore_pos(raffstorepos)
        logf.info("BAD raffstores_down(): Azimuth="+str(azimuth)+"°, Raffstore="+str(raffstorepos)+"%")
        logsys.debug("Beschattung BAD Raffstore "+str(raffstorepos)+"%")
    return

############


## BAD Lamellen positionieren
#
#  @param sh       Object pointer to smarthome master object
#
def lamellen_pos(sh, elevation):
    global logf
    global logsys
    
    if sh.wohnung.bad.maximalbeschattung.aktiv():
        lamellenpos = 100
    else:              # Normalbeschattung
        lamellenpos = 53
        if elevation <= 10:
            lamellenpos = 100
        elif elevation <= 23:
            lamellenpos = 84
        elif elevation <= 34:
            lamellenpos = 69
        elif elevation <= 42:
            lamellenpos = 61

    if round(sh.wohnung.bad.raffstore.lamellen_pos()) != lamellenpos:
        sh.wohnung.bad.raffstore.lamellen_pos(lamellenpos)
        logf.info("BAD lamellen_pos(): Elevation="+str(elevation)+"°, Lamellen="+str(lamellenpos)+"%")
        logsys.debug("Beschattung BAD Lamellen "+str(lamellenpos)+"%")

    return


# ==============================================================================
#
## Begin of main routine of logic raffstores.py
#

# Beschattungsautomatik wird aktiviert / deaktiviert
if (trigger['source'] == 'beschattung.beschattungsautomatik.west'):
    if trigger['value'] == False:
        logf.info("Beschattungsautomatik West deaktiviert")
        logsys.info("Beschattung Beschattungsautomatik BAD deaktiviert")
        if sh.wohnung.bad.beschattungaktiv():
            sh.wohnung.bad.beschattungaktiv(False)
            raffstores_up(sh, sh.mysun.azimuth())
    else:
        logf.info("Beschattungsautomatik West aktiviert")
        logsys.info("Beschattung Beschattungsautomatik BAD aktiviert")
        if (sh.mysun.azimuth() > 265) and (sh.mysun.azimuth() < 330) and (sh.mysun.elevation() > 0.5):
            sh.wohnung.bad.beschattungaktiv(True)


if sh.beschattung.beschattungsautomatik():

    if (trigger['source'] == 'wohnung.bad.maximalbeschattung.aktiv'):
        if  sh.wohnung.bad.maximalbeschattung.aktiv():
            logf.info("Umschaltung Maximalbeschattung BAD -> EIN")
            logsys.info("Beschattung Umschaltung Maximalbeschattung BAD -> EIN")
            raffstores_down(sh, sh.mysun.azimuth())
        else:
            logf.info("Umschaltung Maximalbeschattung BAD -> AUS")
            logsys.info("Beschattung Umschaltung Maximalbeschattung BAD -> AUS")
            raffstores_up(sh, sh.mysun.azimuth())

    # Prüfen ob Sonne im Beschattungsbereich steht (nicht für das BAD!)
    if (trigger['source'] == 'mysun.azimuth') or (trigger['source'] == 'wohnung.bad.maximalbeschattung.aktiv'):

        if ( sh.wohnung.bad.maximalbeschattung.aktiv() ):
            if trigger['source'] == 'wohnung.bad.maximalbeschattung.aktiv':
                sh.wohnung.bad.beschattungaktiv(True)
                logf.info("BAD Lamellen schließen")
                lamellen_pos(sh, sh.mysun.elevation())
        else:
            if (sh.mysun.azimuth() > 265) and (sh.mysun.azimuth() < 330) and (sh.mysun.elevation() > 0.5):
                if not sh.wohnung.bad.beschattungaktiv():
                    logf.info("BAD Beschattung aktiv")
                    logsys.info("Beschattung Beschattung BAD aktiv")
                    sh.wohnung.schlafen.beschattungaktiv(True)
                else:
                    # Bei Befarf Lamelle nachführen, wenn Beschattung bereits aktiv
                   if sh.wohnung.schlafen.raffstore_west.raffstore_pos() != 0:
                       logf.info("BAD Lamellen nachführen")
                       lamellen_pos(sh, sh.mysun.elevation())
            else:
                sh.wohnung.bad.beschattungaktiv(False)

    if (trigger['source'] == 'wohnung.bad.beschattungaktiv'):
        if sh.wohnung.bad.beschattungaktiv():
            # beim Bad nur beschatten, wenn Maximalbeschattung aktiv ist
            if sh.wohnung.bad.maximalbeschattung():
                bad_raffstores_down(sh, sh.mysun.azimuth())
                bad_lamellen_pos(sh, sh.mysun.elevation())

    if (trigger['source'] == 'sh.wohnung.bad.maximalbeschattung'):
        if sh.wohnung.bad.beschattungaktiv():
            logf.info("Umschaltung Maximalbeschattung")
            logsys.info("Beschattung Umschaltung Maximalbeschattung BAD")
            bad_raffstores_down(sh, sh.mysun.azimuth())
            bad_lamellen_pos(sh, sh.mysun.elevation())
