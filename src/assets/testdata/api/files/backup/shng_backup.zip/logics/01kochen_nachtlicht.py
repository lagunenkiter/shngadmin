#!/usr/bin/env python3
# logics/01kochen_nachtlicht.py


logf = logging.getLogger('q21')

#    watch_item = wohnung.kochen.bewegung
#    crontab = init+1 = Init

logic_name = "ko_nachtlicht"
#logf.warning("logic "+logic_name+": trigger[source] = " + str(trigger['source']) + ", trigger[by] = " + str(trigger['by']) + ", trigger[value] = " + str(trigger['value']) )



#
# Nacht Automatik
#

# Downlights bei Bewegung auf Ambiente schalten, wenn Nachtruhe und sonstiges Licht in KO und WZ aus ist

if (trigger['source'] == 'wohnung.kochen.bewegung'):
    if sh.wohnung.stati.nachtruhe() == True:
        if sh.wohnung.kochen.bewegung() == True:
            if (sh.wohnung.kochen.szenen_knx() == 0) and (sh.wohnung.wohnen.szenen_knx() == 0):
                sh.wohnung.kochen.szenen_knx(3)
        else:
            if (sh.wohnung.kochen.szenen_knx() == 3) and (sh.wohnung.wohnen.szenen_knx() == 0):
#                sh.wohnung.kochen.szenen_knx.timer(15, 0)
                sh.wohnung.kochen.szenen_knx(0)

