#comment#test0810#filename: test0810.py#active: False#Vorlage für eine neue Logik
#trigger#test0810#filename: test0810.py#crontab: init = Init#Trigger Beispiel: Bei der Initialisierung auslösen
"""
Logic test0810.py

Vorlage für eine neue Logik

THIS FILE WAS GENERATED FROM A BLOCKY LOGIC WORKSHEET - DON'T EDIT THIS FILE, use the Blockly plugin instead !

to be configured in /etc/logic.yaml:

test0810:
    filename: test0810.py                          # Vorlage für eine neue Logik
    crontab: init = Init                           # Trigger Beispiel: Bei der Initialisierung auslösen
"""
logic_active = False
if (logic_active == True):
  logger.warning('Beispiel: Logeintrag der Logik')
