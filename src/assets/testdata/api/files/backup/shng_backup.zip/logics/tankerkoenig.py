#!/usr/bin/env python3
# tankerkoenig.py

cheapest = sh.tankerkoenig.get_petrol_stations(sh._lat, sh._lon, 'e5', 'price', rad='5')
if cheapest is not None and len(cheapest) > 0:
    logger.info("Cheapest {}: {}".format(cheapest[0], cheapest))
    sh.tankstellen.cheapest.brand_e5(cheapest[0]['brand'])
    sh.tankstellen.cheapest.name_e5(cheapest[0]['name'])
    sh.tankstellen.cheapest.street_e5(cheapest[0]['street'])
    sh.tankstellen.cheapest.isOpen_e5(cheapest[0]['isOpen'])
    sh.tankstellen.cheapest.e5(cheapest[0]['price'])
else:
    logger.info("Cheapest list for Super is empty.")

cheapest = sh.tankerkoenig.get_petrol_stations(sh._lat, sh._lon, 'e10', 'price', rad='5')
if cheapest is not None and len(cheapest) > 0:
    logger.info("Cheapest {}: {}".format(cheapest[0], cheapest))
    sh.tankstellen.cheapest.brand_e10(cheapest[0]['brand'])
    sh.tankstellen.cheapest.name_e10(cheapest[0]['name'])
    sh.tankstellen.cheapest.street_e10(cheapest[0]['street'])
    sh.tankstellen.cheapest.isOpen_e10(cheapest[0]['isOpen'])
    sh.tankstellen.cheapest.e10(cheapest[0]['price'])
else:
    logger.info("Cheapest list for Super E10 is empty.")


detail = sh.tankerkoenig.get_petrol_station_detail(sh.tankstellen.clean_car_steilshoper.conf['tankerkoenig_id'])
if detail != {}:
    logger.info("{}: {}".format(detail['name'], detail))
    sh.tankstellen.clean_car_steilshoper.brand(detail['brand'])
    sh.tankstellen.clean_car_steilshoper.name(detail['name'])
    sh.tankstellen.clean_car_steilshoper.street(detail['street'])
    sh.tankstellen.clean_car_steilshoper.isOpen(detail['isOpen'])
    sh.tankstellen.clean_car_steilshoper.diesel(detail['diesel'])
    sh.tankstellen.clean_car_steilshoper.e10(detail['e10'])
    sh.tankstellen.clean_car_steilshoper.e5(detail['e5'])


detail = sh.tankerkoenig.get_petrol_station_detail(sh.tankstellen.jet_steilshoper.conf['tankerkoenig_id'])
if detail != {}:
    logger.info("{}: {}".format(detail['name'], detail))
    sh.tankstellen.jet_steilshoper.brand(detail['brand'])
    sh.tankstellen.jet_steilshoper.name(detail['name'])
    sh.tankstellen.jet_steilshoper.street(detail['street'])
    sh.tankstellen.jet_steilshoper.isOpen(detail['isOpen'])
    sh.tankstellen.jet_steilshoper.diesel(detail['diesel'])
    sh.tankstellen.jet_steilshoper.e10(detail['e10'])
    sh.tankstellen.jet_steilshoper.e5(detail['e5'])


detail = sh.tankerkoenig.get_petrol_station_detail(sh.tankstellen.lh_tankstelle.conf['tankerkoenig_id'])
if detail != {}:
    logger.info("{}: {}".format(detail['name'], detail))
    sh.tankstellen.lh_tankstelle.brand(detail['brand'])
    sh.tankstellen.lh_tankstelle.name(detail['name'])
    sh.tankstellen.lh_tankstelle.street(detail['street'])
    sh.tankstellen.lh_tankstelle.isOpen(detail['isOpen'])
    sh.tankstellen.lh_tankstelle.diesel(detail['diesel'])
    sh.tankstellen.lh_tankstelle.e10(detail['e10'])
    sh.tankstellen.lh_tankstelle.e5(detail['e5'])





