#!/usr/bin/env python3
# logics/fl_licht.py

#    watch_item = mysun.night | wohnung.config.party | wohnung.stati.nachtruhe | wohnung.stati.hausbesuch | wohnung.flur.config.bwm
#    crontab = init+1

logic_name = "fl_licht"
#logger.warning("logic "+logic_name+": trigger[source] = " + str(trigger['source']) + ", trigger[by] = " + str(trigger['by']) + ", trigger[value] = " + str(trigger['value']) )

# EibPC Flurlichtsteuerung:
# #   UND2(!"Dunkelheit-0/0/4",!"Dunkelheit-0/0/4","Flur Dunkelheit-0/1/4",AUS)
# #   UND2("Dunkelheit-0/0/4","Party-0/0/3","Flur Dunkelheit-0/1/4",AUS)
# #   UND3("Dunkelheit-0/0/4",!"Party-0/0/3",!"Nachtruhe-0/0/2","Flur Dunkelheit-0/1/4",EIN)
#   UND4("Dunkelheit-0/0/4",!"Party-0/0/3","Nachtruhe-0/0/2",!"Hausbesuch-0/0/7","Flur Dunkelheit-0/1/4",AUS)
#   UND4("Dunkelheit-0/0/4",!"Party-0/0/3","Nachtruhe-0/0/2","Hausbesuch-0/0/7","Flur Dunkelheit-0/1/4",EIN)

#
# Steuerung der Downlights als Licht bei Dunkelheit & Bewegung
#
if trigger['source'] == 'wohnung.flur.config.bwm':
    if trigger['value']:
        logger.warning("logic "+logic_name+": Config changed to True")
    else:
        sh.wohnung.flur.bwm_freigabe(False)
        logger.warning("logic "+logic_name+": BWM Freigabe <- False (config changed to False)")

if sh.wohnung.flur.config.bwm():
    if sh.mysun.night():
        if (sh.wohnung.config.party):
            #   UND2("Dunkelheit-0/0/4","Party-0/0/3","Flur Dunkelheit-0/1/4",AUS)
            sh.wohnung.flur.bwm_freigabe(False)
            logger.warning("logic "+logic_name+": BWM Freigabe <- False (Party)")
        else:
            if (not sh.wohnung.stati.nachtruhe()):
                #   UND3("Dunkelheit-0/0/4",!"Party-0/0/3",!"Nachtruhe-0/0/2","Flur Dunkelheit-0/1/4",EIN)
                sh.wohnung.flur.bwm_freigabe(True)
                logger.warning("logic "+logic_name+": BWM Freigabe <- True (not Nachtruhe)")
            else:
                #   UND4("Dunkelheit-0/0/4",!"Party-0/0/3","Nachtruhe-0/0/2",!"Hausbesuch-0/0/7","Flur Dunkelheit-0/1/4",AUS)
                #   UND4("Dunkelheit-0/0/4",!"Party-0/0/3","Nachtruhe-0/0/2","Hausbesuch-0/0/7","Flur Dunkelheit-0/1/4",EIN)
                sh.wohnung.flur.bwm_freigabe( sh.wohnung.config.hausbesuch() )
                logger.warning("logic "+logic_name+": BWM Freigabe <- " + str(sh.wohnung.config.hausbesuch()) + "(= Hausbesuch)")

    else:
        #   UND2(!"Dunkelheit-0/0/4",!"Dunkelheit-0/0/4","Flur Dunkelheit-0/1/4",AUS)
        sh.wohnung.flur.bwm_freigabe(False)
        logger.warning("logic "+logic_name+": BWM Freigabe <- False (day)")

else:
    pass
#    logger.warning("logic "+logic_name+": Config disabled -> Do nothing")
