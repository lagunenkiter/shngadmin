#!/usr/bin/env python3
# logics/az_licht.py


logf = logging.getLogger('q21')

#    watch_item = wohnung.stati.abwesend
#    crontab = init+1 = Init

logic_name = "az_licht"
#logf.warning("logic "+logic_name+": trigger[source] = " + str(trigger['source']) + ", trigger[by] = " + str(trigger['by']) + ", trigger[value] = " + str(trigger['value']) )


# logger.warning("trigger dict: {}".format(trigger))



#
# wenn eine Hue-Leuchte eingeschaltet wird, dann in weiss
#
if (trigger['source']=='wohnung.buero.dreieckschrank.onoff') and (sh.wohnung.buero.dreieckschrank.onoff()):
    sh.wohnung.buero.dreieckschrank.ct(343)


#
# wenn die Schreibtischleuchte eingeschaltet wird (an der Leuchte), dann die Leuchte auf dem Dreieckschrank einschalten, falls der Szenen-Status 0 ist
#
# if (trigger['source']=='wohnung.buero.schreibtischleuchte.status'):
#     if sh.wohnung.buero.szenen_knx() == 0:
#         if sh.wohnung.buero.schreibtischleuchte.status() < 2 :
#             sh.wohnung.buero.dreieckschrank.onoff(False)
#         else:
#             sh.wohnung.buero.dreieckschrank.level(126)
#             sh.wohnung.buero.dreieckschrank.onoff(True)


#
# Abwesenheit: Schreibtischleuchte abschalten (Aktor)
#
if (trigger['source'] == 'wohnung.stati.abwesend'):
    if (trigger['value'] == True):
        sh.wohnung.buero.szenen_knx(0)
        sh.wohnung.buero.schreibtischleuchte.onoff(False)
        logf.info("logic "+logic_name+": Schreibtischleuchte Aktor AUS <- (Abwesend)")
    else:
        sh.wohnung.buero.schreibtischleuchte.onoff(True)
        logf.info("logic "+logic_name+": Schreibtischleuchte Aktor EIN <- (Rückkehr)")


