#!/usr/bin/env python3
# logics/sz_raffstores_nacht.py
#
# Schlafen

# Trigger:
# wohnung.schlafen.raffstores_alle.fahrt | wohnung.schlafen.raffstore_nachtbeschattung_aktiv | mysun.day.nautical | mysun.night.nautical | mysun.day | mysun.day.civil

# Lösung: Auswertung der KNX Taster verhindern solange sh_uptime kleiner als x Sekunden ist
#
# rt = Shtime.get_instance().runtime_as_dict()

import random
import logging
import time
from datetime import datetime, timedelta


mylogger = logging.getLogger('sz_rs_nacht')
logf = logging.getLogger('q21')
logsys = logging.getLogger('syslog')


#    watch_item = wohnung.schlafen.logik_trigger_raffstores | mysun.day.nautical | mysun.night.nautical | mysun.day | mysun.day.civil
#    crontab = init = Init | 15 08 * * = Hoch

logic_name = "sz_raffstores_nacht"
#logger.warning("logic: trigger['source'] = " + str(trigger['source']) + ", trigger[by] = " + str(trigger['by']) + ", trigger[value] = " + str(trigger['value']) )
#logf.warning("logic: trigger['source'] = " + str(trigger['source']) + ", trigger[by] = " + str(trigger['by']) + ", trigger[value] = " + str(trigger['value']) )



## SZ Raffstores West, Nord und Ost hochfahren
#
#  @param sh       Object pointer to smarthome master object
#
def sz_raffstores_up(sh):
    if sh.wohnung.schlafen.raffstore_ost.raffstore_pos() != 0:
        sh.wohnung.schlafen.raffstore_ost.raffstore_pos(0)
        sh.wohnung.schlafen.raffstore_ost.lamellen_pos(0)

        sh.wohnung.schlafen.raffstore_nord.raffstore_pos(0)
        sh.wohnung.schlafen.raffstore_nord.lamellen_pos(0)

        # Falls die Automatik am Taster (Tür BAD) ausgeschaltet wird, fährt der Raffstore West schon
        if sh.wohnung.schlafen.raffstore_west.fahrt == 0:
            sh.wohnung.schlafen.raffstore_west.raffstore_pos(0)
            sh.wohnung.schlafen.raffstore_west.lamellen_pos(0)
    return


## SZ Raffstores abends runterfahren
#
#   Raffstrores Nord und Ost in Position 'Schutz vor Parkplatzlicht' fahren
#   Raffstore West halb runter fahren in Position 'Schutz vor Mondlicht' fahren
#
#   55% -> bis zum Fenstergriff
#   59% -> Ost für Winterhalbjahr ok
#   62% -> Ost normal
#
#  @param sh       Object pointer to smarthome master object
#
def sz_raffstores_down(sh):
    sh.wohnung.schlafen.raffstore_ost.raffstore_pos(int( sh.beschattung.config.automatik_nachtbeschattung_sz.raffstorepos_ost() ))
    sh.wohnung.schlafen.raffstore_ost.lamellen_pos(0)

    sh.wohnung.schlafen.raffstore_nord.raffstore_pos(int( sh.raffstores.maxpos() ))
    sh.wohnung.schlafen.raffstore_nord.lamellen_pos(0)

    sh.wohnung.schlafen.raffstore_west.raffstore_pos(int( sh.beschattung.config.automatik_nachtbeschattung_sz.raffstorepos_west() ))
    sh.wohnung.schlafen.raffstore_west.lamellen_pos(100)
    return


## SZ Raffstores zur Morgendämmerung fahren
#
#   Raffstrores Nord und Ost in Position 'Schutz vor Sonnenaufgang' fahren
#   (nur Lamellen kippen)
#
#  @param sh       Object pointer to smarthome master object
#
def sz_raffstores_dawn(sh):
    if sh.wohnung.schlafen.raffstore_ost.raffstore_pos() != 0:
        sh.wohnung.schlafen.raffstore_ost.lamellen_pos(100)
        sh.wohnung.schlafen.raffstore_nord.lamellen_pos(100)
    return


## Scheduler Handler zum hochfahren der Raffstores
#
# Diese Funktion wird vom Scheduler aufgerufen, um die Raffstores zeitverzögert 
# hochzufahren
#
#  @param self      The object pointer.
#  @param **kwargs  argument list
#
def _sz_raffstores_up(self, **kwargs):
    sh = kwargs['sh']
    sz_raffstores_up(sh)



# ==============================================================================
#
## Begin of main routine of logic raffstores.py
#

if sh.wohnung.schlafen.raffstore_logic_initialized():

    if trigger['source'] == 'wohnung.schlafen.raffstore_nachtbeschattung_aktiv':
        if sh.wohnung.schlafen.raffstore_nachtbeschattung_aktiv():
            logf.info("Nachtbeschattung aktiviert")
            logsys.info("Nacht-Beschattung Nachtbeschattung aktiviert")
            sz_raffstores_down(sh)
        else:
            logf.info("Nachtbeschattung deaktiviert")
            logsys.info("Nacht-Beschattung Nachtbeschattung deaktiviert")
            sz_raffstores_up(sh)

    
    if trigger['source'] == 'wohnung.schlafen.raffstores_alle.fahrt':
        # Taste im SZ gedrückt und Raffstores hochgefahren
        if trigger['value'] == 0:
            if sh.wohnung.schlafen.raffstore_nachtbeschattung_aktiv():
                sh.wohnung.schlafen.raffstore_nachtbeschattung_aktiv(False)
                logf.info("Nachtbeschattung ausgeschaltet (per Taster)")
                logsys.info("Nacht-Beschattung Nachtbeschattung ausgeschaltet (per Taster)")
    

    if sh.beschattung.config.automatik_nachtbeschattung_sz.onoff():
        if sh.wohnung.schlafen.raffstore_logic_initialized():

            now = time.localtime()
            monat = now.tm_mon
            stunde = now.tm_hour
            
            if (trigger['source'] == 'mysun.day.nautical'):
                # Abenddämmerung (im Winter)
                if (sh.mysun.day.nautical() == False) and (stunde >= 14) and ((monat <= 4) or (monat >= 9)):
                    logf.info("Raffstores runter (Nacht, nautisch)")
                    sh.wohnung.schlafen.raffstore_nachtbeschattung_aktiv(True)
                else:
                    logf.info("Day (nautical) -> Do nothing")

            elif (trigger['source'] == 'mysun.day.civil'):
                # Abenddämmerung (im Sommer)
                if (sh.mysun.day.civil() == False) and (monat > 4) and (monat < 9):
                    logf.info("Raffstores runter (Nacht, bürgerlich)")
                    sh.wohnung.schlafen.raffstore_nachtbeschattung_aktiv(True)
                # Morgendämmerung
                if (trigger['value'] == True):
                    if sh.wohnung.schlafen.raffstore_ost.raffstore_pos != 0:
                        logf.info("Lamellen in Position 'Morgendämmerung'")
                        logsys.info("Nacht-Beschattung Lamellen in Position 'Morgendämmerung'")
                        sz_raffstores_dawn(sh)
                    else:
                        logf.info("Raffstores bereits oben (Morgendämmerung)")
                else:
                    logger.info("logic "+logic_name+": Day -> Do nothing")
                    logf.info("Day -> Do nothing")

            elif (trigger['source'] == 'wohnung.config.raffstoreautomatik.sz_nacht'):
                if (trigger['value'] == True):
                    if (sh.mysun.day.nautical() == False):
                        logf.info("Raffstores runter (Nacht, Config=On)")
                        sh.wohnung.schlafen.raffstore_nachtbeschattung_aktiv(True)
                        sz_raffstores_down(sh)

            elif (trigger['by'] == 'Scheduler'):
                if (trigger['value'] == 'Hoch'):
                    logf.info("Raffstores rauf? (cron->hoch, Config=On)")
                    logf.info("-> sh.wohnung.schlafen.raffstore_nachtbeschattung_aktiv()"+str(sh.wohnung.schlafen.raffstore_nachtbeschattung_aktiv()) )
                    if sh.wohnung.schlafen.raffstore_nachtbeschattung_aktiv():
#                        movetime = (datetime.now()+timedelta(minutes=30*random.random())).replace(tzinfo=self._sh.tzinfo())
                        movetime = (datetime.now()+timedelta(minutes=30*random.random())).replace(tzinfo=self.shtime.tzinfo())
                        logf.warning("Raffstores rauf um "+str(movetime)+" (Hoch, Config=On)")
#                    sh.scheduler.add('sz_rs_nacht', sz_raffstores_up, next=movetime)
                        sh.wohnung.schlafen.raffstore_nachtbeschattung_aktiv(False)
                        sz_raffstores_up(sh)

                elif sh.wohnung.stati.abwesend():
                    myvalue = str(trigger['value'])
                    if (str(myvalue[:12]) == 'WennAbwesend'):
                        maxoffset = 30
                        if str(myvalue[:13]) == 'WennAbwesend+':
                            try:
                                maxoffset = int(myvalue[13:])
                            except:
                                pass
#                        movetime = (datetime.now()+timedelta(minutes=maxoffset*random.random())).replace(tzinfo=self._sh.tzinfo())
                        movetime = (datetime.now()+timedelta(minutes=maxoffset*random.random())).replace(tzinfo=self.shtime.tzinfo())
                        logf.info("Raffstores rauf um {0} (Abwesenheit, Config=On)".format(movetime.strftime('%H:%M:%S')) )
                        sh.scheduler.add('sz_rs_nacht.abw', sz_raffstores_up, value={'sh': sh}, next=movetime)


#
## Only initialization after this point
#
if (sh.wohnung.schlafen.raffstore_logic_initialized() == False):
    now = time.localtime()
    monat = now.tm_mon
    if (trigger['source'] == None):
        if (sh.mysun.day.nautical() != sh.mysun.night.nautical()):
#            if (sh.mysun.day.nautical() == False):
            if ((monat <= 4) or (monat >= 9)):
                # Abenddämmerung (im Winter)
                if (sh.mysun.day.nautical() == False):
                    logf.debug("Raffstores runter WinterHJ (Nacht, nautisch) (Init)")
                    sh.wohnung.schlafen.raffstore_nachtbeschattung_aktiv(True)
                    sz_raffstores_down(sh)
                else:
                    logf.debug("Raffstores rauf WinterHJ  (Init)")
                    sh.wohnung.schlafen.raffstore_nachtbeschattung_aktiv(False)
                    sz_raffstores_up(sh)
            else:
                # Abenddämmerung (im Sommer)
                if (sh.mysun.day.civil() == False):
                    logf.debug("Raffstores runter SommerHJ (Nacht, civil) (Init)")
                    sh.wohnung.schlafen.raffstore_nachtbeschattung_aktiv(True)
                    sz_raffstores_down(sh)
                else:
                    logf.debug("Raffstores rauf SommerHJ (Init)")
                    sh.wohnung.schlafen.raffstore_nachtbeschattung_aktiv(False)
                    sz_raffstores_up(sh)
            sh.wohnung.schlafen.raffstore_logic_initialized(1)
        else:
            logf.debug("Night == Day -> Do nothing (Init)")
            sh.wohnung.schlafen.raffstore_logic_initialized(0)

    if (sh.wohnung.schlafen.raffstore_logic_initialized() == False):
        if (trigger['source'] == 'mysun.day.nautical'):
            if ((sh.mysun.day.nautical() == True) and ((monat <= 4) or (monat >= 9))) or ((sh.mysun.day.civil() == True) and ((monat > 4) and (monat < 9))):
                if sh.wohnung.schlafen.raffstore_nachtbeschattung_aktiv():
                    logf.debug("Nachtbeschattung ist noch aktiv -> Do Nothing (Init 2)")
                else:
                    logf.debug("Raffstores rauf (Init 2)")
                    sh.wohnung.schlafen.raffstore_nachtbeschattung_aktiv(False)
                    sz_raffstores_up(sh)
#                    logf.debug("Raffstores unten lassen, Stephan schläft noch (Init 2)")
#                    sh.wohnung.schlafen.raffstore_nachtbeschattung_aktiv(True)
            sh.wohnung.schlafen.raffstore_logic_initialized(1)

        if (trigger['source'] == 'mysun.night.nautical'):
            if (sh.mysun.night.nautical() == True):
                logf.debug("Raffstores runter (Init 2)")
                sh.wohnung.schlafen.raffstore_nachtbeschattung_aktiv(True)
                sz_raffstores_down(sh)
            sh.wohnung.schlafen.raffstore_logic_initialized(1)

    if sh.wohnung.schlafen.raffstore_logic_initialized():
        logf.info("Logic initialisiert")

