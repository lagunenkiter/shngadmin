#!/usr/bin/env python3
# logics/az_licht.py

# Test

logf = logging.getLogger('q21')

#    watch_item = wohnung.stati.abwesend
#    crontab = init+1 = Init

logic_name = "testlogic"
#logf.warning("logic "+logic_name+": trigger[source] = " + str(trigger['source']) + ", trigger[by] = " + str(trigger['by']) + ", trigger[value] = " + str(trigger['value']) )


#####################################################

from lib.logic import Logics
import lib.item

global gtestvar

if not('gtestvar' in globals()) or (str(trigger['value']).lower() == 'init'):
#    logf.warning("logic "+logic_name+": (re)setting global var 'gtestvar'")
    gtestvar = 0

# child = lib.item.Item(self, self, child_path, value)

#     child_path = 'env.logics'
#     value
#     try:
#         child = lib.item.Item(sh, sh, child_path, value)
#     except Exception as e:
#         logf.error("Item {}: problem creating: ()".format(child_path, e))
#
#     child_path = 'env.logics.testlogic.initialized'
#     try:
#         child = lib.item.Item(sh, sh, child_path, value)
#     except Exception as e:
#         logf.error("Item {}: problem creating: ()".format(child_path, e))
#     else:
#         vars(sh)[attr] = child
#         sh.add_item(child_path, child)
#         sh.__children.append(child)

#    sh.env.logics.testlogic.initialized(False)

logics = Logics.get_instance()
mylogic = logics.return_logic('testlogic')
#logf.warning("logic "+logic_name+": mylogic[conf] = '{0}'".format(mylogic.conf))


#####################################################


#
# wenn eine Hue-Leuchte eingeschaltet wird, dann in weiss
#
#if (trigger['source']=='wohnung.buero.dreieckschrank.onoff') and (sh.wohnung.buero.dreieckschrank.onoff()):
#    sh.wohnung.buero.dreieckschrank.ct(343)




#
# Abwesenheit
#
#if (trigger['source'] == 'wohnung.stati.abwesend'):
#    if (trigger['value']):
#        sh.wohnung.buero.schreibtischleuchte(False)
#        logf.info("logic "+logic_name+": Schreibtischleuchte Aktor AUS <- (Abwesend)")
#    else:
#        sh.wohnung.buero.schreibtischleuchte(True)
#        logf.info("logic "+logic_name+": Schreibtischleuchte Aktor EIN <- (Rückkehr)")


#logf.warning("logic "+logic_name+": gtestvar="+str(gtestvar))
gtestvar += 1


