#comment#neue_logik#filename: neue_logik.py#active: True#Logik zum testen des Python Outputs
#trigger#neue_logik#filename: neue_logik.py#cycle: 55 = Sekunden#Jede Minute ausführen
#trigger#neue_logik#filename: neue_logik.py#crontab: ['init = Init','sunrise+10 = Sonne','15 3 * * = Daily']#['Bei der Initialisierung','10 Minuten nach Sonnenaufgang','Jeden Tag um viertel nach 3']
#trigger#neue_logik#filename: neue_logik.py#watch_item: ['beleuchtung.automatik_wuerfel.onoff = Wuerfel','fenster.bad.fenster_nord']#['Ausführen wenn sich der Würfel ändert','']
"""
Logic neue_logik.py

Logik zum testen des Python Outputs

THIS FILE WAS GENERATED FROM A BLOCKY LOGIC WORKSHEET - DON'T EDIT THIS FILE, use the Blockly plugin instead !

to be configured in /etc/logic.yaml:

neue_logik:
    filename: neue_logik.py                        # Logik zum testen des Python Outputs
    cycle: 55 = Sekunden                           # Jede Minute ausführen
    watch_item:
     - beleuchtung.automatik_wuerfel.onoff = Wuerfel
     - fenster.bad.fenster_nord
    crontab:
     - init = Init
     - sunrise+10 = Sonne
     - 15 3 * * = Daily
"""
logic_active = True
if (logic_active == True):
  print(sh.items.return_item("beleuchtung.automatik_wuerfel.onoff"))
  logger.info('Test Logeintrag')
  print(sh.items.return_item("config.knx.busspannung.minimum"))
  print(sh.items.return_item("beleuchtung.automatik_wuerfel.onoff"))
