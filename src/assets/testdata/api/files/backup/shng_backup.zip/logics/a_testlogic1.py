#!/usr/bin/env python3
# logics/create_test.py

logger.warning("logic "+logic.name+"("+logic.filename+"): trigger[source] = " + str(trigger['source']) + ", trigger[by] = " + str(trigger['by']) + ", trigger[value] = " + str(trigger['value']) )
logger.setLevel('WARNING')

if not hasattr(logic, 'myvar'):
    logic.myvar = None

if not hasattr(logics, 'myvar2'):
    logics.myvar2 = None



logger.warning("- logic.myvar: {}".format(logic.myvar))
logger.warning("- logics.myvar2: {}".format(logics.myvar2))


logger.warning("- logic.name: {}".format(logic.name))
logger.warning("- logic.id(): {}".format(logic.id()))

logger.warning("- logic.crontab: {}".format(logic.crontab))
logger.warning("- logic.cycle: {}".format(logic.cycle))
logger.warning("- logic.prio: {}".format(logic.prio))
logger.warning("- logic.last_run(): {}".format(logic.last_run()))

logger.warning("- trigger[]: {}".format(trigger))

logger.warning("- logic.get_method_triggers(): {}".format(logic.get_method_triggers()))

logger.warning("- logic.conf: {}".format(dict(logic.conf)))
logger.warning("- logic.filename: {}".format(logic.filename))

logger.warning("- logics.get_logic_info('a_testlogic1'): {}".format(logics.get_logic_info('a_testlogic1')))
logger.warning("- logics.return_defined_logics(): {}".format(logics.return_defined_logics()))

logic.myvar = 'persistant var'

logics.myvar2 = 'test for non-private var'



logger.warning("Logik '{}' (filename '{}') wurde getriggert (WARNING)".format(logic.name, logic.filename))
logger.info("Logik '{}' (filename '{}') wurde getriggert (INFO)".format(logic.name, logic.filename))
logger.debug("Logik '{}' (filename '{}') wurde getriggert (DEBUG)".format(logic.name, logic.filename))


