#!/usr/bin/env python3
# logics/heizung.py

#    watch_item = wohnung.*.heizung.komfort | wohnung.*.heizung.nacht

# logger.warning("logic: trigger['source'] = " + str(trigger['source']) + ", trigger[by] = " + str(trigger['by']) + ", trigger[value] = " + str(trigger['value']) )


#
# Steuerung des Modi Zusammenspiels für dir RTR Visualisierung
#

# Kochen
if (trigger['source']=='wohnung.kochen.heizung.komfort') and (sh.wohnung.kochen.heizung.komfort()):
    sh.wohnung.kochen.heizung.nacht(0, 'Logic '+logic.name)
if (trigger['source']=='wohnung.kochen.heizung.nacht') and (sh.wohnung.kochen.heizung.nacht()):
    sh.wohnung.kochen.heizung.komfort(0, 'Logic '+logic.name)

# Wohnen
if (trigger['source']=='wohnung.wohnen.heizung.komfort') and (sh.wohnung.wohnen.heizung.komfort()):
    sh.wohnung.wohnen.heizung.nacht(0, 'Logic '+logic.name)
if (trigger['source']=='wohnung.wohnen.heizung.nacht') and (sh.wohnung.wohnen.heizung.nacht()):
    sh.wohnung.wohnen.heizung.komfort(0, 'Logic '+logic.name)

# Essen
if (trigger['source']=='wohnung.essen.heizung.komfort') and (sh.wohnung.essen.heizung.komfort()):
    sh.wohnung.essen.heizung.nacht(0, 'Logic '+logic.name)
if (trigger['source']=='wohnung.essen.heizung.nacht') and (sh.wohnung.essen.heizung.nacht()):
    sh.wohnung.essen.heizung.komfort(0, 'Logic '+logic.name)

# Gast
if (trigger['source']=='wohnung.gast.heizung.komfort') and (sh.wohnung.gast.heizung.komfort()):
    sh.wohnung.gast.heizung.nacht(0, 'Logic '+logic.name)
if (trigger['source']=='wohnung.gast.heizung.nacht') and (sh.wohnung.gast.heizung.nacht()):
    sh.wohnung.gast.heizung.komfort(0, 'Logic '+logic.name)

# Buero
if (trigger['source']=='wohnung.buero.heizung.komfort') and (sh.wohnung.buero.heizung.komfort()):
    sh.wohnung.buero.heizung.nacht(0, 'Logic '+logic.name)
if (trigger['source']=='wohnung.buero.heizung.nacht') and (sh.wohnung.buero.heizung.nacht()):
    sh.wohnung.buero.heizung.komfort(0, 'Logic '+logic.name)

# Dusche
if (trigger['source']=='wohnung.dusche.heizung.komfort') and (sh.wohnung.dusche.heizung.komfort()):
    sh.wohnung.dusche.heizung.nacht(0, 'Logic '+logic.name)
if (trigger['source']=='wohnung.dusche.heizung.nacht') and (sh.wohnung.dusche.heizung.nacht()):
    sh.wohnung.dusche.heizung.komfort(0, 'Logic '+logic.name)

# Schlafen
if (trigger['source']=='wohnung.schlafen.heizung.komfort') and (sh.wohnung.schlafen.heizung.komfort()):
    sh.wohnung.schlafen.heizung.nacht(0, 'Logic '+logic.name)
if (trigger['source']=='wohnung.schlafen.heizung.nacht') and (sh.wohnung.schlafen.heizung.nacht()):
    sh.wohnung.schlafen.heizung.komfort(0, 'Logic '+logic.name)

# Bad
if (trigger['source']=='wohnung.bad.heizung.komfort') and (sh.wohnung.bad.heizung.komfort()):
    sh.wohnung.bad.heizung.nacht(0, 'Logic '+logic.name)
if (trigger['source']=='wohnung.bad.heizung.nacht') and (sh.wohnung.bad.heizung.nacht()):
    sh.wohnung.bad.heizung.komfort(0, 'Logic '+logic.name)

