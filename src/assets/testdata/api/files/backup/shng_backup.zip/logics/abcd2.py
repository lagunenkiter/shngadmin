#!/usr/bin/env python3
# abcd2.py

if sh.wohnung.wohnen.tv.status() > 5 and sh.beschattung.beschattungsautomatik.sued():
    a = 5
else:
    a = 0
