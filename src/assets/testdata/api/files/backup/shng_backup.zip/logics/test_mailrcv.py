#!/usr/bin/env python3
# test_mailrcv.py

logger.warning("Received Mail - trigger = {}".format(trigger))

mail = trigger['value']

# import email
# from email.parser import BytesParser
# simplest = mail.get_body(preferencelist=('plain', 'html'))


# logger.warning("mail = {}".format(mail))
logger.warning("mail['From'] = {}".format(mail['From']))
logger.warning("mail['To'] = {}".format(mail['To']))
logger.warning("simplest = {}".format(simplest))

# logger.warning("mail.keys = {}".format(mail.keys))

