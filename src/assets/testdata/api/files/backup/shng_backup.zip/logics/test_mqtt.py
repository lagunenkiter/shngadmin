#!/usr/bin/env python3
# logics/test01.py


logf = logging.getLogger('q21')

#    watch_item = wohnung.kochen.bewegung
#    crontab = init+1 = Init

logic_name = "test_mqtt"
logf.warning("logic "+logic_name+": trigger[source] = " + str(trigger['source']) + ", trigger[by] = " + str(trigger['by']) + ", trigger[value] = " + str(trigger['value']) )

