#!/usr/bin/ping_devices
# logics/ping_devices.py

if not sh.tools.ping('mlgw.fritz.box'):
    logger.error("Logik '{}' (filename '{}') meldet FEHLER: MLGW antwortet nicht".format(logic.name, logic.filename))

