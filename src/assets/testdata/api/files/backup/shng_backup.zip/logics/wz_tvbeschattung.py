#!/usr/bin/env python3
# wz_tvbeschattung.py

# Beschattung Süd zwischen 84° und 255° Azimuth


# Erst bei mysun.azimuth > 125° die TV Beschattung aktivieren, davor nur TV Stand (Trigger anpassen)
# To do: Bei WZ Helligkeit über 500 bereits ab 110° TV Beschattung aktivieren
# To do: Wenn keine Beschattung des WZ mehr am Nachmittag, TV Beschattung nicht aktivieren, nur TV Stand 
# To do: im Winterhalbjahr erweiterte Beschattung anpassen: am 31.10. 163,2° Az und 20,9° Elev. Sonne im Augenwinkel
# - aktuell schaltet die erweiterte Beschattung bei 169,9° Az zu.
# - Erweiterte Beschattung wird z.Zt. im eval von Item wohnung.wohnen.tvbeschattung_erweitert gesteuert.



#--------------------------
# Initialisierung

now = time.localtime()
nowhour = time.localtime()[3]
nowminute = time.localtime()[4]


#--------------------------
# Soll-Zustände bestimmen

# Soll Zustand TV-Stand bestimmen
tvstand_beschattung = False
if sh.beschattung.beschattungsautomatik() or sh.mysun.elevation() > 3.5:
    if (sh.mysun.azimuth() > 85  and sh.mysun.azimuth() < 305) or \
       (nowhour < 12 and sh.mysun.elevation() > 14) or \
       (nowhour >= 12 and sh.mysun.elevation() > 6):
        if sh.wohnung.wohnen.tv.status() > 4:
            # nur Beschattungszustand, wenn TV-Mode größer im Audio-Mode
            tvstand_beschattung = True
    logger.info("tvstand_beschattung: {}".format(tvstand_beschattung))



# Soll Zustand Raffstore Beschattung bestimmen
tvbeschattung = False
if sh.beschattung.beschattungsautomatik.sued():
    if sh.mysun.azimuth() > 125 and sh.mysun.azimuth() < 255:
        if sh.wohnung.wohnen.tv.status() > 5:
            tvbeschattung = True
    logger.info("tvbeschattung: {}".format(tvbeschattung))


        
#-------------------
# Zustände setzen

# TV-Stand Zustand setzen
if tvstand_beschattung != sh.wohnung.wohnen.tv.stand_beschattung():
    # nur ausgeben bei Veränderung
    # if sh.wohnung.wohnen.tv.status() > 5 and (not sh.wohnung.stati.abwesend()):
    # nur ausgeben, wenn TV eingeschaltet (um ungewolltes einschalten zu vermeiden)
    sh.wohnung.wohnen.tv.stand_beschattung(tvstand_beschattung, 'wz_tvbeschattung')
    logger.info("tvstand_beschattung setzen: {}".format(tvstand_beschattung))


        
# Raffstore Zustand setzen
if tvbeschattung != sh.wohnung.wohnen.tvbeschattung():
    # nur ausgeben bei Veränderung
    sh.wohnung.wohnen.tvbeschattung(tvbeschattung, 'wz_tvbeschattung')
    logger.info("wz_tvbeschattung setzen: {}".format(tvbeschattung))


