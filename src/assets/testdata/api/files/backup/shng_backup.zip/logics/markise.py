#!/usr/bin/env python3
# logics/markise.py
#
# Markisen Schutz

#    watch_item = wetter.wetter_icon

logic_name = "markise"
#logger.warning("logic: trigger['source'] = " + str(trigger['source']) + ", trigger[by] = " + str(trigger['by']) + ", trigger[value] = " + str(trigger['value']) )


logw = logging.getLogger('q21-wetter')
logf = logging.getLogger('q21')
logsys = logging.getLogger('syslog')



# ==============================================================================
#
## Begin of main routine of logic raffstores.py
#

# Beschattungsautomatik wird aktiviert / deaktiviert
if (trigger['source'] == 'wetter.wetter_icon'):
    if trigger['value'] == 'rain':
        logf.info("Markise hochfahren (Regen)")
        logsys.info("Markise hochfahren (Regen)")
        logw.info("Markise hochfahren (Regen)")
        sh.wohnung.terrasse.markise.position( 0 )

    if trigger['value'] == 'tstorms':
        logf.info("Markise hochfahren (Gewitter)")
        logsys.info("Markise hochfahren (Gewitter)")
        logw.info("Markise hochfahren (Gewitter)")
        sh.wohnung.terrasse.markise.position( 0 )
