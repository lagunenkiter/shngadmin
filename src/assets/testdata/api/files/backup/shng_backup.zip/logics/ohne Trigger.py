"""
Logic ohne_trigger.py

Logik zum testen des Python Outputs

THIS FILE WAS GENERATED FROM A BLOCKY LOGIC WORKSHEET - DON'T EDIT THIS FILE, use the Blockly plugin instead !
"""
logic_active = True
if (logic_active == True):
  print(sh.return_item("beleuchtung.automatik_wuerfel.onoff"))
  logger.info('Test Logeintrag')
  print(sh.return_item("config.knx.busspannung.minimum"))
  print(sh.return_item("beleuchtung.automatik_wuerfel.onoff"))
