#!/usr/bin/env python3
# test_source.py

sh.test.test_eval.button(1,'logic: test')