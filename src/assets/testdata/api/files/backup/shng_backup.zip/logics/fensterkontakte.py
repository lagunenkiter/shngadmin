#!/usr/bin/env python3
# logics/fensterkontakte.py
#
# Schlafen

import logging


#logf = logging.getLogger('q21-dev')
#logsys = logging.getLogger('syslog')


#	watch_item = wohnung.dusche.bewegung | wohnung.bad.bewegung | wohnung.stati.nachtruhe | wohnung.stati.abwesend | wohnung.stati.kochen | mysun.summer
#	crontab = init = Init

logic_name = "fensterkontakte"
#logf.info("logic: trigger['source'] = " + str(trigger['source']) + ", trigger['by'] = " + str(trigger['by']) + ", trigger['value'] = " + str(trigger['value']) )

