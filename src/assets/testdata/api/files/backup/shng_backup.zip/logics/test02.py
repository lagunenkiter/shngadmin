#!/usr/bin/env python3
# logics/test02.py


logf = logging.getLogger('q21')

#    watch_item = wohnung.kochen.bewegung
#    crontab = init+1 = Init

logic_name = "test_02"
logf.warning("logic "+logic_name+": trigger[source] = " + str(trigger['source']) + ", trigger[by] = " + str(trigger['by']) + ", trigger[value] = " + str(trigger['value']) )

sh.smartvisu.url("index.php", '10.0.0.165')
