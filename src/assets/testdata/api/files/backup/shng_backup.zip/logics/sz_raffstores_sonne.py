#!/usr/bin/env python3
# logics/sz_raffstores_sonne.py
#
# Schlafzimmer Beschattung

#    watch_item = mysun.azimuth | mysun.elevation

logfsun = logging.getLogger('q21-sun')
logf = logging.getLogger('q21')
logsys = logging.getLogger('syslog')

logic_name = "sz_rs_sonne"

#logger.warning("logic "+logic_name+": trigger[source] = " + str(trigger['source']) + ", trigger[by] = " + str(trigger['by']) + ", trigger[value] = " + str(trigger['value']) )



## SZ Raffstores Nord und Ost hochfahren
#
#  @param sh       Object pointer to smarthome master object
#
def raffstores_ne_up(sh, azimuth):
    global logf
    global logsys
    raffstorepos = 0
    if sh.wohnung.schlafen.raffstore_ost.raffstore_pos() != raffstorepos:
        sh.wohnung.schlafen.raffstore_ost.raffstore_pos(raffstorepos)
        sh.wohnung.schlafen.raffstore_ost.lamellen_pos(0)
        logf.info("raffstores_up(): Azimuth="+str(azimuth)+"°, Raffstorepos Ost="+str(raffstorepos)+"%")
        logsys.debug("SZ Beschattung SZo Raffstore "+str(raffstorepos)+"%")
    if sh.wohnung.schlafen.raffstore_nord.raffstore_pos() != raffstorepos:
        sh.wohnung.schlafen.raffstore_nord.raffstore_pos(raffstorepos)
        sh.wohnung.schlafen.raffstore_nord.lamellen_pos(0)
        logf.info("SZ raffstores_up(): Azimuth="+str(azimuth)+"°, Raffstorepos Nord="+str(raffstorepos)+"%")
        logsys.debug("Beschattung SZn Raffstore "+str(raffstorepos)+"%")

    return


## SZ Raffstores Nord und Ost runterfahren
#
#  @param sh       Object pointer to smarthome master object
#
def raffstores_ne_down(sh, azimuth):
    global logf
    global logsys
    raffstorepos = sh.raffstores.maxpos()
    if round(sh.wohnung.schlafen.raffstore_ost.raffstore_pos()) != raffstorepos:
        sh.wohnung.schlafen.raffstore_ost.raffstore_pos(raffstorepos)
        logf.info("SZ raffstores_down(): Azimuth="+str(azimuth)+"°, Raffstore Ost="+str(raffstorepos)+"%")
        logsys.debug("Beschattung SZo Raffstore "+str(raffstorepos)+"%")
    if round(sh.wohnung.schlafen.raffstore_nord.raffstore_pos()) != raffstorepos:
        sh.wohnung.schlafen.raffstore_nord.raffstore_pos(raffstorepos)
        logf.info("SZ raffstores_down(): Azimuth="+str(azimuth)+"°, Raffstore Nord="+str(raffstorepos)+"%")
        logsys.debug("Beschattung SZn Raffstore "+str(raffstorepos)+"%")

    return
    

## SZ Raffstores West hochfahren
#
#  @param sh       Object pointer to smarthome master object
#
def raffstores_up(sh, azimuth):
    global logf
    global logsys
    raffstorepos = 0
    if sh.wohnung.schlafen.raffstore_west.raffstore_pos() != raffstorepos:
        sh.wohnung.schlafen.raffstore_west.raffstore_pos(raffstorepos)
        sh.wohnung.schlafen.raffstore_west.lamellen_pos(0)
        logf.info("SZ raffstores_up(): Azimuth="+str(azimuth)+"°, Raffstorepos West="+str(raffstorepos)+"%")
        logsys.debug("Beschattung SZw Raffstore "+str(raffstorepos)+"%")
#    raffstores_ne_up(sh, azimuth)

    return


## SZ Raffstores West runterfahren
#
#  @param sh       Object pointer to smarthome master object
#
def raffstores_down(sh, azimuth):
    global logf
    global logsys
    raffstorepos = sh.raffstores.maxpos()
    if round(sh.wohnung.schlafen.raffstore_west.raffstore_pos()) != raffstorepos:
        sh.wohnung.schlafen.raffstore_west.raffstore_pos(raffstorepos)
        logf.info("SZ raffstores_down(): Azimuth="+str(azimuth)+"°, Raffstore West="+str(raffstorepos)+"%")
        logsys.debug("Beschattung SZw Raffstore "+str(raffstorepos)+"%")
#    if sh.wohnung.schlafen.maximalbeschattung.aktiv():
#        raffstores_ne_down(sh, azimuth)

    return


## SZ Lamellen West positionieren
#
#  @param sh       Object pointer to smarthome master object
#
def sz_lamellen_pos(sh, elevation):
    global logf
    global logsys
    
    if sh.wohnung.schlafen.maximalbeschattung.aktiv():
        lamellenpos = 100
    elif sh.wohnung.schlafen.tvbeschattung():
        lamellenpos = 80
    else:              # Normalbeschattung
        lamellenpos = 53
        if elevation <= 10:
            lamellenpos = 100
        elif elevation <= 23:
            lamellenpos = 84
        elif elevation <= 34:
            lamellenpos = 69
        elif elevation <= 42:
            lamellenpos = 61

    if round(sh.wohnung.schlafen.raffstore_west.lamellen_pos()) != lamellenpos:
        sh.wohnung.schlafen.raffstore_west.lamellen_pos(lamellenpos)
        logf.info("SZ lamellen_pos(): Elevation="+str(elevation)+"°, Lamellen West="+str(lamellenpos)+"%")
        logsys.debug("Beschattung SZw Lamellen "+str(lamellenpos)+"%")

    if sh.wohnung.schlafen.maximalbeschattung.aktiv():
        if round(sh.wohnung.schlafen.raffstore_ost.lamellen_pos()) != lamellenpos:
            sh.wohnung.schlafen.raffstore_ost.lamellen_pos(lamellenpos)
            logf.info("SZ lamellen_pos(): Elevation="+str(elevation)+"°, Lamellen Ost="+str(lamellenpos)+"%")
            logsys.debug("Beschattung SZo Lamellen "+str(lamellenpos)+"%")
        if round(sh.wohnung.schlafen.raffstore_nord.lamellen_pos()) != lamellenpos:
            sh.wohnung.schlafen.raffstore_nord.lamellen_pos(lamellenpos)
            logf.info("SZ lamellen_pos(): Elevation="+str(elevation)+"°, Lamellen Nord="+str(lamellenpos)+"%")
            logsys.debug("Beschattung SZn Lamellen "+str(lamellenpos)+"%")

    return


# ==============================================================================
#
## Begin of main routine of logic raffstores.py
#

# Beschattungsautomatik wird aktiviert / deaktiviert
if (trigger['source'] == 'beschattung.beschattungsautomatik.west'):
    if trigger['value'] == False:
        logf.info("Beschattungsautomatik West deaktiviert")
        logsys.info("Beschattung Beschattungsautomatik SZ deaktiviert")
        if sh.wohnung.schlafen.beschattungaktiv():
            sh.wohnung.schlafen.beschattungaktiv(False)
            raffstores_up(sh, sh.mysun.azimuth())
            raffstores_ne_up(sh, sh.mysun.azimuth())
    else:
        logf.info("Beschattungsautomatik West aktiviert")
        logsys.info("Beschattung Beschattungsautomatik SZ aktiviert")
        if ((sh.mysun.azimuth() > 220) and (sh.mysun.azimuth() < 330) and (sh.mysun.elevation() > 1.7)) or (sh.wohnung.schlafen.maximalbeschattung.aktiv()):
            sh.wohnung.schlafen.beschattungaktiv(True)


if sh.beschattung.beschattungsautomatik():

    if (trigger['source'] == 'wohnung.schlafen.maximalbeschattung.aktiv'):
        if sh.wohnung.schlafen.maximalbeschattung.aktiv():
            logf.info("Umschaltung Maximalbeschattung SZ -> EIN")
            logsys.info("Beschattung Umschaltung Maximalbeschattung SZ -> EIN")
            if sh.wohnung.schlafen.raffstore_nachtbeschattung_aktiv():
                logf.info("Ausschaltung Nachtbeschattung")
                sh.wohnung.schlafen.raffstore_nachtbeschattung_aktiv(false)
            raffstores_ne_down(sh, sh.mysun.azimuth())
        else:
            logf.info("Umschaltung Maximalbeschattung SZ -> AUS")
            logsys.info("Beschattung Umschaltung Maximalbeschattung SZ -> AUS")
            raffstores_ne_up(sh, sh.mysun.azimuth())

    # Prüfen ob Sonne im Beschattungsbereich steht
    if (trigger['source'] == 'mysun.azimuth') or (trigger['source'] == 'wohnung.schlafen.maximalbeschattung.aktiv'):

        if ( sh.wohnung.schlafen.maximalbeschattung.aktiv() ):
#            if trigger['source'] == 'wohnung.schlafen.maximalbeschattung.aktiv':
#      	      sh.wohnung.schlafen.beschattungaktiv(True)
#        	    logf.info("SZ West Lamellen schließen")
            	sz_lamellen_pos(sh, sh.mysun.elevation())
        else:
            if (sh.mysun.azimuth() > 220) and (sh.mysun.azimuth() < 330) and (sh.mysun.elevation() > 1.7):
                if not sh.wohnung.schlafen.beschattungaktiv():
                    logf.info("Beschattung aktiv")
                    logsys.info("Beschattung Beschattung SZ aktiv")
                    sh.wohnung.schlafen.beschattungaktiv(True)
                else:
                    # Bei Befarf Lamelle nachführen, wenn Beschattung bereits aktiv
                   if sh.wohnung.schlafen.raffstore_west.raffstore_pos() != 0:
                       logf.info("SZ West Lamellen nachführen")
                       sz_lamellen_pos(sh, sh.mysun.elevation())
            else:
                sh.wohnung.schlafen.beschattungaktiv(False)

    if (trigger['source'] == 'wohnung.schlafen.beschattungaktiv'):
        if sh.wohnung.schlafen.beschattungaktiv():
            raffstores_down(sh, sh.mysun.azimuth())
            if sh.wohnung.schlafen.maximalbeschattung.aktiv():
                raffstores_ne_down(sh, sh.mysun.azimuth())
            
            sz_lamellen_pos(sh, sh.mysun.elevation())
#        elif (sh.mysun.azimuth() >= 330) or (sh.mysun.elevation() <= 1.7):
#            if (sh.wohnung.schlafen.raffstore_nachtbeschattung_aktiv() == False):
#                raffstores_up(sh, sh.mysun.azimuth())
        elif (sh.wohnung.schlafen.raffstore_nachtbeschattung_aktiv() == False):
            raffstores_up(sh, sh.mysun.azimuth())
            raffstores_ne_up(sh, sh.mysun.azimuth())
                

