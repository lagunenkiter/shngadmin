#comment#test#filename: test.py#active: False#Logik Test
#trigger#test#filename: test.py#crontab: init = Init#Bei der Initialisierung
"""
Logic test.py

Logik Test

THIS FILE WAS GENERATED FROM A BLOCKY LOGIC WORKSHEET - DON'T EDIT THIS FILE, use the Blockly plugin instead !

to be configured in /etc/logic.yaml:

test:
    filename: test.py                              # Logik Test
    crontab: init = Init                           # Bei der Initialisierung
"""
logic_active = False
if (logic_active == True):
  logger.warning('Test Logeintrag')
