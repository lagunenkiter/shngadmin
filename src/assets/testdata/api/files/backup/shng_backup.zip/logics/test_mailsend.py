#!/usr/bin/env python3
# test_mailsend.py

sh.mymail.send("ms@msinn.de", "Testmail aus SHNG", "Und hier ist der Text")
logger.warning("Mail gesendet")
sh.mymail2.send("ms@msinn.de", "Testmail aus SHNG", "Und hier ist der zweite Text")
logger.warning("2. Mail gesendet")


