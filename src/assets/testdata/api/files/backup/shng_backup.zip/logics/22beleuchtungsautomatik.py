#!/usr/bin/env python3
# logics/22beleuchtungsautomatik.py

#    crontab = init | sunrise+1m | sunset+1m | sunrise-6 | sunset-6 | sunset-12
#    cycle = 1800

logf = logging.getLogger('q21')

# logger.warning("logic "+logic.name+": trigger[source] = " + str(trigger['source']) + ", trigger[by] = " + str(trigger['by']) + ", trigger[value] = " + str(trigger['value']) )


# Noch zu implementieren:
#
# - Nicht ausschalten wenn Partymode ON
# - (Nicht einschalten wenn Partymode ON und Würfel bereits ON (Farbe) sind.)
# - Nicht reaktivieren nach manuellem ausschalten
# - Schalter 'Automatik bei Abwesenheit'

# Auswertung Automatik Ein/AUS
#if (trigger['source']=='beleuchtung.config.automatik_wuerfel.onoff'):
#    if sh.beleuchtung.config.automatik_wuerfel.onoff():

now = time.localtime()
nowhour = time.localtime()[3]
nowminute = time.localtime()[4]

if (trigger['source']=='mysun.elevation'):
	# Auswertung Elevation (einschalten)
	if (sh.beleuchtung.config.automatik_wuerfel.onoff()):
		if (nowhour > 12):
			if sh.mysun.elevation() < sh.beleuchtung.config.automatik_wuerfel.elevation_ein():
				if not(sh.wohnung.terrasse.wuerfel_schalter()):
					sh.wohnung.terrasse.wuerfel_schalter('on', 'Logic '+logic.name)
					logf.info('Würfel eingeschaltet (Elevation='+str(sh.mysun.elevation())+')')

else:
	# Auswertung Uhrzeit (ausschalten)
	if sh.beleuchtung.config.automatik_wuerfel.onoff() and(not sh.wohnung.terrasse.wandleuchten_ost()):
		if (nowhour < 4):
			if (sh.beleuchtung.config.automatik_wuerfel.zeit_aus() < nowhour + nowminute/60):
				sh.wohnung.terrasse.wuerfel_schalter('off', 'Logic '+logic.name)
				logf.info('Würfel ausgeschaltet')
