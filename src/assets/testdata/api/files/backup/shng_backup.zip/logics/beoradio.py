#!/usr/bin/env python3
# logics/beoradio.py

#    watch_item = beoremote.beo4dvdcommandnum

logic_name = "beoradio"
logger.warning("logic "+logic_name+": trigger[source] = " + str(trigger['source']) + ", trigger[by] = " + str(trigger['by']) + ", trigger[value] = " + str(trigger['value']) )

try:
	digit = int(trigger['value'])
except:
	digit = 0
	
# einstellige Presets
if (digit > 0) and (digit < 10):
    items.return_item('myradio.station')( digit )
    logger.warning("logic "+logic_name+": Switched to preset "+str(digit))
