#!/usr/bin/env python3
# logics/config_stati.py

#    watch_item = mysun.night | wohnung.config.status_party
#    crontab = init+1 = Init | 44 23 * * = Nachtruhe

logic_name = "config_stati"
# logger.warning("logic "+logic_name+": trigger[source] = " + str(trigger['source']) + ", trigger[by] = " + str(trigger['by']) + ", trigger[value] = " + str(trigger['value']) )


#
# Bla, Bla, Bla
#

# Gast
#if (trigger['source']=='wohnung.config.status_party') and (sh.wohnung.config.status_party()):
#    sh.wohnung.dusche....(0)

#if (trigger['source']=='wohnung.buero....') and (sh.wohnung.buero.... == 0) and (sh.wohnung.config.status_party()):
#    sh.wohnung.buero.... (6)

#
# Steuerung des Nachtuhe-Status
#

logf = logging.getLogger('q21')

# // Steuerung des Status "Nachtruhe"
# if (htime(23,45,00)) then write("Nachtruhe-0/0/2",EIN) endif
# if !"Dunkelheit-0/0/4" then write("Nachtruhe-0/0/2",AUS) endif
if (trigger['source'] == 'mysun.night') and (not trigger['value']):
    sh.wohnung.stati.nachtruhe(0)
    logf.info("Nachtruhe AUS <- (day)")

if str(trigger['value']) == 'Nachtruhe':
    sh.wohnung.stati.nachtruhe(1)
    logf.info("Nachtruhe EIN <- (Nachtruhe)")

if str(trigger['value']) == 'Init':
    if sh.mysun.night() == False:
        sh.wohnung.stati.nachtruhe(0)
        logf.info("Nachtruhe AUS <- (Init, day)")
    else:
        localtime = time.localtime(time.time())
        if ((localtime.tm_hour == 23) and (localtime.tm_min >= 44)) or (localtime.tm_hour < 9):
            sh.wohnung.stati.nachtruhe(1)
            logf.info("Nachtruhe EIN <- (Init, time)")
