#!/usr/bin/env python3
# logics/create_test2.py

logger.warning("logic "+logic.name+"("+logic.filename+"): trigger[source] = " + str(trigger['source']) + ", trigger[by] = " + str(trigger['by']) + ", trigger[value] = " + str(trigger['value']) )


# import logging

if not hasattr(logic, 'myvar'):
    logic.myvar = None

if not hasattr(logics, 'myvar2'):
    logics.myvar2 = None

logger.warning("- logic.myvar: {}".format(logic.myvar))
logger.warning("- logics.myvar2: {}".format(logics.myvar2))

logger.warning("trigger dict: {}".format(trigger))



#mylogger = logging.getLogger('create_test2')

logger.warning("Logik 'create_test2' wurde getriggert (WARNING)")
logger.info("Logik 'create_test2' wurde getriggert (INFO)")
logger.debug("Logik 'create_test2' wurde getriggert (DEBUG)")

#mylogger.warning("Logik 'create_test2' wurde getriggert (WARNING)")
#mylogger.info("Logik 'create_test2' wurde getriggert (INFO)")
#mylogger.debug("Logik 'create_test2' wurde getriggert (DEBUG)")

