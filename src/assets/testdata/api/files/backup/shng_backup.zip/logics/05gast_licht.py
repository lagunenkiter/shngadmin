#!/usr/bin/env python3
# logics/gz_licht.py


logf = logging.getLogger('q21')

#    watch_item = wohnung.gast.*.onoff | mysun.night | wohnung.stati.nachtruhe | wohnung.stati.abwesend | wohnung.config.party | wohnung.gast.config.tischleuchte
#    crontab = init+1 = Init

logic_name = "gz_licht"
# logf.warning("trigger[source] = " + str(trigger['source']) + ", trigger[by] = " + str(trigger['by']) + ", trigger[value] = " + str(trigger['value']) )


#
# wenn eine Hue-Leuchte eingeschaltet wird, dann in weiss und in voller Helligkeit
#
if (trigger['source']=='wohnung.gast.tischleuchte.onoff') and (sh.wohnung.gast.tischleuchte.onoff()):
    sh.wohnung.gast.tischleuchte.ct(343)
    sh.wohnung.gast.tischleuchte.level(255)


#
# Steuerung der Tischleuchte als Dauerlicht bei Dunkelheit (Umschalten in Config)
#
if trigger['source'] == 'wohnung.gast.config.tischleuchte':
    if trigger['value']:
        logf.info("Config changed to True")
        if sh.mysun.night() and (not sh.wohnung.stati.nachtruhe()) and (not sh.wohnung.stati.abwesend()):
            sh.wohnung.gast.tischleuchte.onoff(True)
            logf.warning("Tischleuchte EIN <- (night)")
    else:
        logf.info("Config changed to False)")
        sh.wohnung.gast.tischleuchte.onoff(False)
        logf.info("Tischleuchte AUS <- (config=off)")

#
# Steuerung der Tischleuchte als Dauerlicht bei Dunkelheit
#
if sh.wohnung.gast.config.tischleuchte() and (not sh.wohnung.config.party()):
    if (trigger['source'] == 'mysun.night') and trigger['value']:
        if not sh.wohnung.stati.abwesend():
            sh.wohnung.gast.tischleuchte.onoff(True)
            logf.info("Tischleuchte EIN <- (night)")

    # 
    # WENN: Trigger = SZ Licht aus   UND: SZ TV ist an   UND: GZ nicht genutzt (Decke AUS und Säule AUS und evtl. iMac auf Standby)
    if (trigger['source'] == 'wohnung.schlafen.szenen_knx') and (trigger['value'] == 0):
        if not sh.wohnung.stati.abwesend():
            if (sh.wohnung.schlafen.tv.status() > 1) and sh.wohnung.gast.tischleuchte.onoff() and sh.wohnung.gast.status.unbenutzt():
                sh.wohnung.gast.tischleuchte.level(int(2.56 * 40))
                logf.info("Tischleuchte dimmen <- (night)")
            else:
                logf.info("SZ Licht aus: TV="+str(sh.wohnung.schlafen.tv.status())+", unbenutzt="+str(sh.wohnung.gast.status.unbenutzt())+", Tischleuchte="+str(sh.wohnung.gast.tischleuchte.onoff()))

    if (trigger['source'] == 'wohnung.stati.nachtruhe') and trigger['value']:
        sh.wohnung.gast.tischleuchte.onoff(False)
        logf.info("Tischleuchte AUS <- (Nachtruhe)")

    if (trigger['source'] == 'wohnung.stati.abwesend'):
        if sh.mysun.night():
            if (not trigger['value']) and (not sh.wohnung.stati.nachtruhe()):
                sh.wohnung.gast.tischleuchte.onoff(True)
                logf.info("logic "+logic_name+": Tischleuchte EIN <- (Rückkehr)")

    #
    # Init wenn Steuerung der Tischleuchte als Dauerlicht bei Dunkelheit
    #
    if (str(trigger['value']) == 'Init'):
        if sh.mysun.night():
            if sh.wohnung.stati.nachtruhe():
                sh.wohnung.gast.tischleuchte.onoff(False)
                logf.info("logic "+logic_name+": Tischleuchte AUS <- (Init, Nachtruhe)")
            else:
                sh.wohnung.gast.tischleuchte.onoff(True)
                logf.info("Tischleuchte EIN <- (Init, night)")
        if sh.wohnung.stati.abwesend():
            sh.wohnung.gast.tischleuchte.onoff(False)
            logf.info("Tischleuchte AUS <- (Init, abwesend)")

else:
    logf.debug("Logic disabled in Config -> Do nothing")


#
# Abwesenheit
#
if (trigger['source'] == 'wohnung.stati.abwesend') and (trigger['value']):
    sh.wohnung.gast.tischleuchte.onoff(False)
    logf.info("Tischleuchte AUS <- (Abwesend)")
    sh.wohnung.gast.saeulenleuchte(False)
    logf.info("Säulenleuchte AUS <- (Abwesend)")
