#!/usr/bin/env python3
# logics/01kochen_licht.py


logf = logging.getLogger('q21')

#    watch_item = wohnung.kochen.helligkeit
#    crontab = init+1 = Init

logic_name = "ko_licht"
#logf.warning("logic "+logic_name+": trigger[source] = " + str(trigger['source']) + ", trigger[by] = " + str(trigger['by']) + ", trigger[value] = " + str(trigger['value']) )




#
# Abschaltung der Ambiente Beleuchtung, wenn es hell genug ist
#
if (str(trigger['value']) == 'Init'):
    logf.info("logic "+logic_name+": szenen_knx="+str(sh.wohnung.kochen.szenen_knx())+", helligkeit="+str(sh.wohnung.kochen.helligkeit())+", helligkeit.prev_value="+str(sh.wohnung.kochen.helligkeit.prev_value()) )

# Licht aus, wenn aktuelle Szene=Ambiente und die Hellihkeit über 40 Lux steigt
ausschalthelligkeit = 40

if (trigger['source'] == 'wohnung.kochen.helligkeit'):
    if sh.wohnung.kochen.szenen_knx() == 3 and sh.wohnung.kochen.helligkeit() > ausschalthelligkeit and sh.wohnung.kochen.helligkeit.prev_value() <= ausschalthelligkeit:
        sh.wohnung.kochen.szenen_knx(0)
        logf.info("logic "+logic_name+": Szene Ambiente ausgeschaltet, da Raum hell genug ("+str(ausschalthelligkeit)+" Lux)")
