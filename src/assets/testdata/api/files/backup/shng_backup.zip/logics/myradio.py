#!/usr/bin/env python3
# logics/myradio.py

# 15.03.2015	preset > preset_max -> preset = preset_max


logr = logging.getLogger('q21-radio')
logf = logging.getLogger('q21')

logic_name = "myradio"
#    watch_item = myradio.station | myradio.store | sonos_bo.track_album_art | sonos_bo.track_title

preset_max   = 10                  # station numbers from 01 to 10
pathforradio = 'myradio'           # beginning of path for all radio items
pathforsonos = 'mysonos'           # beginning of path for all sonos items for the sonos-player to control

coverwhenoff = '/smartvisu/icons/ws/audio_sound.png'


#if (trigger['source'] != pathforsonos+'.track_album_art') and (trigger['source'] != pathforsonos+'.track_title'):
#    logr.warning("trigger['source'] = " + str(trigger['source']) + ", trigger[by] = " + str(trigger['by']) + ", trigger[value] = " + str(trigger['value']) )


## Get attribue of a radiostation preset
#
#   ...
#
#  @param sh          global sh object of smarthome.py
#  @param presetnr    string with presetnumber ('00', '01', ...)
#  @param presetattr  name of attribute to get ('name', 'uri', 'cover_art')
#  @param triggertype type of calling trigger ('recall' or 'cover)
#  @returns           string with the attribute
#
def _getpresetattr( sh, presetnr, presetattr, triggertype ):
    global pathforradio
    global logic_name
    global logr
    path = pathforradio+'.s'+presetnr+'.'+presetattr
    item = sh.items.return_item(path)
    if item == None:
        logr.error("("+triggertype+"): item '"+path+"' is not defined in items.conf")
        return ''
    else:
        logr.debug("("+triggertype+"): getting station "+presetattr+" for preset "+presetnr+' -> '+str(item()) )
    return item()


## Set attribue of a radiostation preset
#
#   ...
#
#  @param sh          global sh object of smarthome.py
#  @param presetnr    string with presetnumber ('00', '01', ...)
#  @param presetattr  name of attribute to set ('name', 'uri', 'cover_art')
#  @param attrvalue   string with value to set the attribute to
#
def _setpresetattr( sh, presetnr, presetattr, attrvalue ):
    global pathforradio
    global logic_name
    global logr
    path = pathforradio+'.s'+presetnr+'.'+presetattr
    item = sh.items.return_item(path)
    if item == None:
        logr.error("(store): item '"+path+"' is not defined in items.conf")
        return
    else:
        logr.debug("(store): setting station "+presetattr+" for preset "+presetnr+" to '"+str(attrvalue)+"'" )
        item( str(attrvalue) )
    return


#
# Read configuration
#
item = sh.items.return_item(pathforradio)
try:
    pathforsonos = item.conf['sonos_section']
except:
    pass 

try:
    preset_max = int(item.conf['preset_max'])
except:
    pass 
	

#
# Store or select radio station
#
if trigger['source'] == pathforradio+'.station':
    if trigger['value'] > preset_max:
        trigger['value'] = preset_max
        sh.items.return_item(pathforradio+'.station')( preset_max, 'name', 'recall_max' )
    else:
        logr.debug("trigger['value'] = '" + str(trigger['value']) + "'" )
        storeitem = sh.items.return_item(pathforradio+'.store')
        if (trigger['value'] > 0) and (trigger['value'] <= preset_max):
    #        logr.warning("trigger['value'] = '" + str(trigger['value']) + "'" )
            preset = str(trigger['value']+900).lstrip('9')
    #        logr.warning("preset = '" + preset + "'" )
            if storeitem():
                _setpresetattr(sh, preset, 'uri', sh.items.return_item(pathforsonos+'.track_uri')())
                wrk = sh.items.return_item(pathforsonos+'.radio_station')()
                if wrk[-4:] == '.com': wrk = wrk[:-4]
                _setpresetattr(sh, preset, 'name', wrk)
                _setpresetattr(sh, preset, 'cover_art', sh.items.return_item(pathforsonos+'.track_album_art')())
                logr.warning("Stored preset "+preset+": "+sh.items.return_item(pathforsonos+'.radio_station')())
                logf.warning("Stored preset "+preset+": "+sh.items.return_item(pathforsonos+'.radio_station')())
                storeitem(0)
            else:
                sh.items.return_item(pathforsonos+'.play_uri')( _getpresetattr(sh, preset, 'uri', 'recall' ) )
                sh.items.return_item(pathforsonos+'.track_album_art')( _getpresetattr(sh, preset, 'cover_art', 'recall' ) )
                sh.items.return_item(pathforsonos+'.radio_station')( _getpresetattr(sh, preset, 'name', 'recall' ) )
                logr.info("Switching to station "+preset+' - '+sh.items.return_item(pathforsonos+'.radio_station')() )
                logf.info("Switching to station "+preset+' - '+sh.items.return_item(pathforsonos+'.radio_station')() )
        else:
            # Stop Sonos player
            if (trigger['value'] == 0) and (not storeitem()):
                sh.items.return_item(pathforsonos+'.play_uri')( '' )
                sh.items.return_item(pathforsonos+'.track_album_art')( coverwhenoff )
                sh.items.return_item(pathforsonos+'.track_title')( '' )
                sh.items.return_item(pathforsonos+'.track_artist')( '' )
                sh.items.return_item(pathforsonos+'.radio_station')( '' )
                logr.info("Switching radio stations off")
                logf.info("Switching radio stations off")


#
# Re-call cover-art and station name, if overwritten with '' by Sonos
#
elif trigger['source'] == pathforsonos+'.track_album_art':
    if trigger['value'] == '':
        stationitem = sh.items.return_item(pathforradio+'.station')
        logr.debug("Re-Call: stationname & coverart for stationitem = '"+str(stationitem())+"'")
        if stationitem() > 0:
            preset = str(stationitem()+900).lstrip('9')
            sh.items.return_item(pathforsonos+'.track_album_art')( _getpresetattr(sh, preset, 'cover_art', 'recall' ) )
            sh.items.return_item(pathforsonos+'.radio_station')( _getpresetattr(sh, preset, 'name', 'recall' ) )
        else:
            sh.items.return_item(pathforsonos+'.track_album_art')( coverwhenoff )

#
# Shorten track_title, fif it contains almost the complete url
#
elif trigger['source'] == pathforsonos+'.track_title':
    if sh.items.return_item(pathforradio+'.station')() == 0:
            sh.items.return_item(pathforsonos+'.track_title')( '' )
    elif len(trigger['value']) > 30:
        logr.debug("'track_title' too long")
        i = trigger['value'].find('?')
        if i == 0: i = 30
        sh.items.return_item(pathforsonos+'.track_title')( trigger['value'][:i] )

#
# Log activation/deactivation of store-mode
#
elif trigger['source'] == pathforradio+'.store':
    if trigger['value']:
        logr.info("'Store preset' activated")
    else:
        logr.info("'Store preset' deactivated")
    
#
# Initialization
#
elif trigger['value'] == 'Init':
    try:
        sonos_uid = sh.items.return_item(pathforsonos).conf['sonos_uid']
    except:
        logr.error("No valid sonos section defined")
    else:
        logr.warning("Using sonos section [" + pathforsonos + "], sonos_uid = "+sonos_uid)
    # Set station again to trigger logic with right trigger/parameter
    sh.items.return_item(pathforradio+'.station')( sh.items.return_item(pathforradio+'.station')() )
    
else:
    logr.warning( "unhandled trigger "+str(trigger['source'])+', value='+str(trigger['value']) )

