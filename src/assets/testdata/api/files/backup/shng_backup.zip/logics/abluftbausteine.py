#!/usr/bin/env python3
# logics/abluftbausteine.py
#
# Schlafen

import logging
import time
from datetime import datetime, timedelta


logf = logging.getLogger('q21')
logsys = logging.getLogger('syslog')


#	watch_item = wohnung.dusche.bewegung | wohnung.bad.bewegung | wohnung.stati.nachtruhe | wohnung.stati.abwesend | wohnung.stati.kochen | mysun.summer
#	crontab = init = Init

logic_name = "abluftbausteine"
#logf.info("logic: trigger['source'] = " + str(trigger['source']) + ", trigger['by'] = " + str(trigger['by']) + ", trigger['value'] = " + str(trigger['value']) )


## Abluftbaustein Küche steuern
#
#  @param sh       Object pointer to smarthome master object
#  @param stufe    Object pointer to smarthome master object
#
def abluft_kochen_steuern(sh, stufe, caller):
    if stufe == 0:
        sh.wohnung.kochen.abluft.stufe1(False, caller)
        sh.wohnung.kochen.abluft.stufe2(False, caller)
    elif stufe == 1:
        sh.wohnung.kochen.abluft.stufe1(True, caller)
        sh.wohnung.kochen.abluft.stufe2(False, caller)
    elif stufe == 2:
        sh.wohnung.kochen.abluft.stufe1(False, caller)
        sh.wohnung.kochen.abluft.stufe2(True, caller)
    else:
        logf.warning("Kochen: Ungültige Stufe {}".format(stufe))
    return


## Abluftbaustein Dusche steuern
#
#  @param sh       Object pointer to smarthome master object
#  @param stufe    Object pointer to smarthome master object
#
def abluft_dusche_steuern(sh, stufe, caller):
    if stufe == 0:
        sh.wohnung.dusche.abluft.stufe1(False, caller)
        sh.wohnung.dusche.abluft.stufe2(False, caller)
    elif stufe == 1:
        sh.wohnung.dusche.abluft.stufe1(True, caller)
        sh.wohnung.dusche.abluft.stufe2(False, caller)
    elif stufe == 2:
        sh.wohnung.dusche.abluft.stufe1(False, caller)
        sh.wohnung.dusche.abluft.stufe2(True, caller)
    else:
        logf.warning("Dusche: Ungültige Stufe {}".format(stufe))
    return


## Abluftbaustein Hauswirtschaft steuern
#
#  @param sh       Object pointer to smarthome master object
#  @param stufe    Object pointer to smarthome master object
#
def abluft_hauswirtschaft_steuern(sh, stufe, caller):
    if stufe == 0:
        sh.wohnung.hauswirtschaft.abluft.stufe1(False, caller)
        sh.wohnung.hauswirtschaft.abluft.stufe2(False, caller)
    elif stufe == 1:
        sh.wohnung.hauswirtschaft.abluft.stufe1(True, caller)
        sh.wohnung.hauswirtschaft.abluft.stufe2(False, caller)
    elif stufe == 2:
        sh.wohnung.hauswirtschaft.abluft.stufe1(False, caller)
        sh.wohnung.hauswirtschaft.abluft.stufe2(True, caller)
    else:
        logf.warning("Hauswirtschaft: Ungültige Stufe {}".format(stufe))
    return


## Abluftbaustein Bad steuern
#
#  @param sh       Object pointer to smarthome master object
#  @param stufe    Object pointer to smarthome master object
#
def abluft_bad_steuern(sh, stufe, caller):
    if stufe == 0:
        sh.wohnung.bad.abluft.stufe1(False, caller)
        sh.wohnung.bad.abluft.stufe2(False, caller)
    elif stufe == 1:
        sh.wohnung.bad.abluft.stufe1(True, caller)
        sh.wohnung.bad.abluft.stufe2(False, caller)
    elif stufe == 2:
        sh.wohnung.bad.abluft.stufe1(False, caller)
        sh.wohnung.bad.abluft.stufe2(True, caller)
    else:
        logf.warning("Bad: Ungültige Stufe {}".format(stufe))
    return


## Abluftbaustein Technik steuern
#
#  @param sh       Object pointer to smarthome master object
#  @param stufe    Object pointer to smarthome master object
#
def abluft_technik_steuern(sh, stufe, caller):
    if stufe == 0:
        sh.wohnung.technik.abluft.stufe1(False, caller)
        sh.wohnung.technik.abluft.stufe2(False, caller)
    elif stufe == 1:
        sh.wohnung.technik.abluft.stufe1(True, caller)
        sh.wohnung.technik.abluft.stufe2(False, caller)
    elif stufe == 2:
        sh.wohnung.technik.abluft.stufe1(False, caller)
        sh.wohnung.technik.abluft.stufe2(True, caller)
    else:
        logf.warning("Technik: Ungültige Stufe {}".format(stufe))
    return


# ==============================================================================
#
# Begin of main routine of logic abluftbausteine.py
#

if str(trigger['source']) != 'fenster.bad.fenster' or int(sh.fenster.bad.fenster.age()) < 60:


    caller = logic.lname

    # Bestimmung des Lüftung-Grundprogramms
    if sh.wohnung.stati.kochen():
        lueftungsprogramm = 'Kochlüftung'
        abluft_kochen = 2
        abluft_dusche = 0
        abluft_hauswirtschaft = 0
        abluft_bad = 0
        abluft_technik = 0
    elif sh.wohnung.stati.abwesend():
        lueftungsprogramm = 'Abwesenheitslüftung'
        abluft_kochen = 1
        abluft_dusche = 1
        abluft_hauswirtschaft = 1
        abluft_bad = 1
        abluft_technik = 1
    elif sh.wohnung.stati.nachtruhe():
        lueftungsprogramm = 'Nachtlüftung'
        abluft_kochen = -1
        abluft_dusche = 1
        abluft_hauswirtschaft = 0
        abluft_bad = 0
        abluft_technik = 1
    elif sh.mysun.summer():
        lueftungsprogramm = 'Normallüftung'
        abluft_kochen = 0
        abluft_dusche = -1
        abluft_hauswirtschaft = 1
        abluft_bad = -1
        abluft_technik = 1
    elif not(sh.mysun.summer()):   # winter
        lueftungsprogramm = 'Winterlüftung'
        abluft_kochen = -1
        abluft_dusche = 1
        abluft_hauswirtschaft = 1
        abluft_bad = -1
        abluft_technik = 1
    else:
        logf.warning("Lüftungs-Grundprogramm kann nicht bestimmt werden.")


    if abluft_kochen == -1:
        # Nachtlüftung im Winter
        if sh.mysun.summer():
            abluft_kochen = 0
        elif sh.wohnung.stati.nachtruhe():
    #        abluft_kochen = 1 (erstmal keine Nachtlüftung)
            abluft_kochen = 0
            pass
        else:
            abluft_kochen = 0


    if abluft_dusche == -1:
        if trigger['source'] == 'wohnung.dusche.bewegung':
            if trigger['value'] == True:
                abluft_dusche = 1
            else:
                # hier fehlt die Nutzungslüftung (Nachlaufsteuerung)
                abluft_dusche = 1
        else:
            abluft_dusche = 1


    if abluft_bad == -1:
#        logger.warning("wohnung.bad.fenster.nord.griff = {}".format(sh.wohnung.bad.fenster.nord.griff()))
        if (sh.wohnung.bad.fenster.nord.griff() > 0) or (sh.wohnung.bad.tuer.kontakt() > 0):
            abluft_bad = 0
        else:
            # hier fehlt die Nutzungslüftung (Nachlaufsteuerung)
            # trigger['source'] == 'wohnung.bad.bewegung'
            abluft_bad = 1


    abluft_kochen_steuern(sh, abluft_kochen, caller)
    abluft_dusche_steuern(sh, abluft_dusche, caller)
    abluft_hauswirtschaft_steuern(sh, abluft_hauswirtschaft, caller)
    abluft_bad_steuern(sh, abluft_bad, caller)
    abluft_technik_steuern(sh, abluft_technik, caller)

    logf.info("Trigger: {}={}, {}: Kochen={}, Dusche={}, Hauswirtschaft={}, Bad={}, Technik={}".format(str(trigger['source']), str(trigger['value']), lueftungsprogramm, abluft_kochen, abluft_dusche, abluft_hauswirtschaft, abluft_bad, abluft_technik))

