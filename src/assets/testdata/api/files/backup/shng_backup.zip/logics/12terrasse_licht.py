#!/usr/bin/env python3

# zentrales Schalten der Aussenwürfel (On=weiss, Off=aus)
if (trigger['source']=='wohnung.terrasse.wuerfel_schalter'):
 #   if sh.wohnung.terrasse.wuerfel_schalter.ignore_next_scene():
 #       sh.wohnung.terrasse.wuerfel_schalter.ignore_next_scene( 0 )
 #   else:
    if sh.wohnung.terrasse.wuerfel_schalter():
        sh.wohnung.terrasse.hue_szenen( '141895143-on-0', 'Logic '+logic.name )      # Szene weiss
    else:
        sh.wohnung.terrasse.hue_szenen( '4f307cad6-on-0', 'Logic '+logic.name )      # Szene AUS

# aktualisieren des Tastsensors bei Wahl einer Szene
if (trigger['source']=='wohnung.terrasse.hue_szenen'):
#    if sh.wohnung.terrasse.hue_szenen() == 'd2412db60-on-0':	# bis 10.10.15
    if sh.wohnung.terrasse.hue_szenen() == '4f307cad6-on-0':
#        sh.wohnung.terrasse.wuerfel_schalter.ignore_next_scene( 1 )
        sh.knx.groupwrite('1/2/39', 0, '1')
    else:
#        sh.wohnung.terrasse.wuerfel_schalter.ignore_next_scene( 1 )
        sh.knx.groupwrite('1/2/39', 1, '1')
