#!/usr/bin/env python3
# logics/create_test3.py

logger.warning("Logik '{}' (filename '{}') wurde getriggert (WARNING)".format(logic.name, logic.filename))

sh.test.dict.var_dict3({'1': 'Wert 1', 2: 'Wert 2 (mit integer Key)'})

logger.warning("Logik '{}': test.dict.var_dict3 = '{}'".format(logic.name, sh.test.dict.var_dict3()))

