#!/usr/bin/env python3
# logics/mysunmoon.py

import logging
import time
from datetime import datetime, timedelta, timezone

#    crontab = init+1 | sunrise+1m | sunset+1m | sunrise-6 | sunset-6 | sunset-12
#    cycle = 1800

logf = logging.getLogger('q21')
#logfmoon = logging.getLogger('q21-moon')

logic_name = "mysunmoon"
# logger.warning("logic "+logic_name+": trigger[source] = " + str(trigger['source']) + ", trigger[by] = " + str(trigger['by']) + ", trigger[value] = " + str(trigger['value']) )


if sh.sun:

#
# azimut, altitude = sh.sun.pos() # return the current sun position
# azimut, altitude = sh.sun.pos(30) # return the sun position 30 minutes in the future.
#

    #
    # setting day and night
    #
    try:
        day = sh.sun.rise(-4).day != sh.sun.set(-4).day
        sh.mysun.day(day, logic.lname)
        sh.mysun.night(not day, logic.lname)
    except Exception as e:
        logger.warning("logic "+logic_name+": ephem Fehler beim bestimmen von Tag/Nacht: {}".format(e))
    
    # setting day and night (civil)
    try:
        day = sh.sun.rise(-6).day != sh.sun.set(-6).day
        sh.mysun.day.civil(day, logic.lname)
        sh.mysun.night.civil(not day, logic.lname)
    except Exception as e:
        logger.warning("logic "+logic_name+": ephem Fehler beim bestimmen von Tag/Nacht (bürgerlich): {}".format(e))
    
    # setting day and night (nautical)
    try:
        day = sh.sun.rise(-12).day != sh.sun.set(-12).day
        sh.mysun.day.nautical(day, logic.lname)
        sh.mysun.night.nautical(not day, logic.lname)
    except Exception as e:
        logger.warning("logic "+logic_name+": ephem Fehler beim bestimmen von Tag/Nacht (nautisch): {}".format(e))



    try:
#        sh.mysun.sunrise(sh.sun.rise().astimezone(sh.tzinfo()).strftime("%H:%M:%S"), logic.lname)
        sh.mysun.sunrise(sh.sun.rise().astimezone(shtime.tzinfo()).strftime("%H:%M:%S"), logic.lname)
    except Exception as e:
        logger.warning("logic "+logic_name+": ephem Fehler beim bestimmen des Sonnenaufgangs: {}".format(e))
    try:
#        sh.mysun.sunset(sh.sun.set().astimezone(sh.tzinfo()).strftime("%H:%M:%S"), logic.lname)
        sh.mysun.sunset(sh.sun.set().astimezone(shtime.tzinfo()).strftime("%H:%M:%S"), logic.lname)
    except Exception as e:
        logger.warning("logic "+logic_name+": ephem Fehler beim bestimmen des Sonnenuntergangs: {}".format(e))
    
    try:
        sh.mysun.dawn(sh.sun.rise(-4).astimezone(shtime.tzinfo()).strftime("%H:%M:%S"), logic.lname)
    except Exception as e:
        logger.warning("logic "+logic_name+": ephem Fehler beim bestimmen der Morgendämmerung: {}".format(e))
    try:
        sh.mysun.dusk(sh.sun.set(-4).astimezone(shtime.tzinfo()).strftime("%H:%M:%S"), logic.lname)
    except Exception as e:
        logger.warning("logic "+logic_name+": ephem Fehler beim bestimmen der Abenddämmerung: {}".format(e))

    #
    # Bestimmung der bürgerlichen, nautischen und astronomischen Dämmerung
    #
    try:
        sh.mysun.dawn.civil(sh.sun.rise(-6).astimezone(shtime.tzinfo()).strftime("%H:%M:%S"), logic.lname)
    except Exception as e:
        logger.warning("logic "+logic_name+": ephem Fehler beim bestimmen der bürgerlichen Morgendämmerung: {}".format(e))
    try:
        sh.mysun.dusk.civil(sh.sun.set(-6).astimezone(shtime.tzinfo()).strftime("%H:%M:%S"), logic.lname)
    except Exception as e:
        logger.warning("logic "+logic_name+": ephem Fehler beim bestimmen der bürgerlichen Abenddämmerung: {}".format(e))

    try:
        sh.mysun.dawn.nautical(sh.sun.rise(-12).astimezone(shtime.tzinfo()).strftime("%H:%M:%S"), logic.lname)
    except Exception as e:
        logger.warning("logic "+logic_name+": ephem Fehler beim bestimmen der nautischen Morgendämmerung: {}".format(e))
    try:
        sh.mysun.dusk.nautical(sh.sun.set(-12).astimezone(shtime.tzinfo()).strftime("%H:%M:%S"), logic.lname)
    except Exception as e:
        logger.warning("logic "+logic_name+": ephem Fehler beim bestimmen der nautischen Abenddämmerung: {}".format(e))

    try:
        sh.mysun.dawn.astronomical(sh.sun.rise(-18).astimezone(shtime.tzinfo()).strftime("%H:%M:%S"), logic.lname)
    except Exception as e:
        sh.mysun.dawn.astronomical('-')
        logger.info("logic "+logic_name+": Fehler in 'sh.sun.rise()' beim bestimmen der astronomischen Morgendämmerung: {}".format(e))
    try:
        sh.mysun.dusk.astronomical(sh.sun.set(-18).astimezone(shtime.tzinfo()).strftime("%H:%M:%S"), logic.lname)
    except Exception as e:
        sh.mysun.dusk.astronomical('-')
        logger.info("logic "+logic_name+": Fehler in 'sh.sun.set()' beim bestimmen der astronomischen Abenddämmerung: {}".format(e))

    now = time.localtime()
    monat = now.tm_mon
    sh.mysun.summer( (monat > 4) and (monat < 9), logic.lname )

    #
    # Mond-Daten bestimmen
    #
    sh.mymoon.moonrise(sh.moon.rise().astimezone(shtime.tzinfo()).strftime("%H:%M:%S"), logic.lname)
    sh.mymoon.moonset(sh.moon.set().astimezone(shtime.tzinfo()).strftime("%H:%M:%S"), logic.lname)
    sh.mymoon.moonphase(sh.moon.phase(), logic.lname)
    sh.mymoon.moonlight(sh.moon.light(), logic.lname)
   
    #
    # Himmelsrichtung von Mond Auf- u. Untergang bestimmen
    #
    diff = sh.moon.rise()-datetime.now(timezone.utc)
    diffminutes = 60*(diff.seconds // 3600) + diff.seconds // 60 % 60
    azimuth, elevation = sh.moon.pos(diffminutes)
    wrk = str(azimuth).split(':')
    sh.mymoon.moonrise.azimuth( round( int(wrk[0]) + int(wrk[1])/60, 1 ), logic.lname )
    
    diff = sh.moon.set()-datetime.now(timezone.utc)
    diffminutes = 60*(diff.seconds // 3600) + diff.seconds // 60 % 60
    azimuth, elevation = sh.moon.pos(diffminutes)
    wrk = str(azimuth).split(':')
    sh.mymoon.moonset.azimuth( round( int(wrk[0]) + int(wrk[1])/60, 1 ), logic.lname )
    logger.info('Mondaufgang um '+sh.mymoon.moonrise()+' bei Azimuth '+str(sh.mymoon.moonrise.azimuth()) + ' und Monduntergang um '+sh.mymoon.moonset()+' bei Azimuth '+str(sh.mymoon.moonset.azimuth()))
    logf.info('Mondaufgang um '+sh.mymoon.moonrise()+' bei Azimuth '+str(sh.mymoon.moonrise.azimuth()) + ' und Monduntergang um '+sh.mymoon.moonset()+' bei Azimuth '+str(sh.mymoon.moonset.azimuth()))
#    logfmoon.info('Mondaufgang um '+sh.mymoon.moonrise()+' bei Azimuth '+str(sh.mymoon.moonrise.azimuth()) + ' und Monduntergang um '+sh.mymoon.moonset()+' bei Azimuth '+str(sh.mymoon.moonset.azimuth()))
 
   
 
#    sh.mymoon.abovethehorizon(True|False)
